#pragma once

namespace ghc {
class HubHTTP;
}