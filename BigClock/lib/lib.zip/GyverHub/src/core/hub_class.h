#pragma once
#include <Arduino.h>

class GyverHub;