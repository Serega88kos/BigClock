#pragma once
#include <Arduino.h>
#include <StringUtils.h>

class Pair : public Text {
   public:
    Text key;
};