#pragma once

#define FASTLED_FORCE_INLINE __attribute__((always_inline)) inline