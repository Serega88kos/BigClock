/// @file fastspi_dma.h
/// Direct memory access (DMA) functions for SPI interfaces
/// @deprecated This header file is empty.
